from setuptools import setup 
setup(name= "vivaan",
version= "0.4",
description="This Is My First Module(Self-Made)",
author= "Vivaan Pawar",
packages=["packagevivaan"],
install_requires=[]
)
